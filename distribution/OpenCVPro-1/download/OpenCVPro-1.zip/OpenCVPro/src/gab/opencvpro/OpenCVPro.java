/**
 * OpenCVPro
 * A collection of utilities for solving this and that problem.
 * http://yourlibraryname.com
 *
 * Copyright (C) 2012 Greg Borenstein http://gregborenstein.com
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA  02111-1307  USA
 * 
 * @author      Greg Borenstein http://gregborenstein.com
 * @modified    03/31/2013
 * @version     0.1.1 (1)
 */



package gab.opencvpro;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.awt.image.DataBufferInt;

import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;


import processing.core.*;

/**
 * This is a template class and can be used to start a new processing library or tool.
 * Make sure you rename this class as well as the name of the example package 'template' 
 * to your own library or tool naming convention.
 * 
 * @example Hello 
 * 
 * (the tag @example followed by the name of an example included in folder 'examples' will
 * automatically include the example in the javadoc.)
 *
 */

public class OpenCVPro {
	
	// myParent is a reference to the parent sketch
	PApplet parent;

	int myVariable = 0;
	
	public final static String VERSION = "0.1.1";
	Mat buffer1;

	/**
	 * a Constructor, usually called in the setup() method in your sketch to
	 * initialize and start the library.
	 * 
	 * @example Hello
	 * @param theParent
	 */
	
    static{ System.loadLibrary("opencv_java244"); }
	
	public OpenCVPro(PApplet theParent, int width, int height) {
		parent = theParent;
		welcome();
		System.out.println("Welcome to Java OpenCV " + Core.VERSION);
        //System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
		
		buffer1 = new Mat(height, width, CvType.CV_32S);
		
	}
	
	public void copy(PImage img){
		BufferedImage image = (BufferedImage)img.getNative();
		
		int[] pixels = ((DataBufferInt)image.getRaster().getDataBuffer()).getData();
		buffer1.put(0, 0, pixels);
	}
	
	public PImage toPImage(Mat mat){
		PImage result = parent.createImage(mat.width(), mat.height(), PConstants.RGB);
		result.loadPixels();
		mat.get(0,0,result.pixels);
		result.updatePixels();

		return result;
	}
	
	public PImage getBuffer(){
		return toPImage(buffer1);
	}
	
	private void welcome() {
		System.out.println("OpenCVPro 0.1.1 by Greg Borenstein http://gregborenstein.com");
	}
	
	
	public String sayHello() {
		return "hello library.";
	}
	/**
	 * return the version of the library.
	 * 
	 * @return String
	 */
	public static String version() {
		return VERSION;
	}

	/**
	 * 
	 * @param theA
	 *          the width of test
	 * @param theB
	 *          the height of test
	 */
	public void setVariable(int theA, int theB) {
		myVariable = theA + theB;
	}

	/**
	 * 
	 * @return int
	 */
	public int getVariable() {
		return myVariable;
	}
}

